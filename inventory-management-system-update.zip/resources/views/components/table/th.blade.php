@props([

])

<th scope="col" {{ $attributes->class(['align-middle text-center']) }}>
    {{ $slot }}
</th>
